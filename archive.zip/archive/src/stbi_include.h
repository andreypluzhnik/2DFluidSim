#ifndef GL_STB_IMAGE_H
#define GL_STB_IMAGE_H


#define STB_IMAGE_IMPLEMENTATION
#include "stb_image/stb_image.h"

#endif