
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <math.h>

#include "stbi_include.h"
#include "shader.h"
#include "bitmap.h"
#include "shader_program.h"


void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void processInput(GLFWwindow *window);

// settings
const unsigned int SCR_WIDTH = 512;
const unsigned int SCR_HEIGHT = 512;

const char* vertexPath = "vertex_shader.glsl";
const char* fragmentPath = "fragment_shader.glsl";
const char* computePath = "compute_shader_textures.glsl";
const char* textureLoadPath = "ssbo_to_texture.glsl";

enum ShaderType{
    COMPUTE_SSBO,
    COMPUTE_TEXTURE,
    COMPUTE_SSBO_VERTEX
};

int main(){
    ShaderType programShader = COMPUTE_TEXTURE;
    // glfw: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    // glfw window creation
    // --------------------
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "ComputeShader", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    // glad: load all OpenGL function pointers
    // ---------------------------------------
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    Shader shader(vertexPath, fragmentPath); 
    ComputeShader compute_shader(computePath);
    ComputeShader ssbo_to_texture(textureLoadPath);

float vertices[] = {
        // positions          // colors           // texture coords
         1.0f,  1.0f, 0.0f,   1.0f, 0.0f, 0.0f,   1.0f, 1.0f, // top right
         1.0f, -1.0f, 0.0f,   0.0f, 1.0f, 0.0f,   1.0f, 0.0f, // bottom right
        -1.0f, -1.0f, 0.0f,   0.0f, 1.0f, 1.0f,   0.0f, 0.0f, // bottom left
        -1.0f,  1.0f, 0.0f,   1.0f, 1.0f, 0.0f,   0.0f, 1.0f  // top left 
    };
    unsigned int indices[] = {  
        0, 1, 3, // first triangle
        1, 2, 3  // second triangle
    };
    // vertex arrays and buffers setup
    // -------------------------
    unsigned int VBO, VAO, EBO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_DYNAMIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_DYNAMIC_DRAW);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    // color attribute
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    // texture coord attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);



    // declare two textures
    GLuint textures[2];
    glGenTextures(2, textures);
    

    // load and create a texture 
    // -------------------------
    
    
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textures[0]); // all upcoming GL_TEXTURE_2D operations now have effect on this texture object
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);	// set texture wrapping to GL_REPEAT (default wrapping method)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    
    // load image from color bitmap
    bitmap color_map(SCR_WIDTH, SCR_HEIGHT);
    color_map.bars_laplacian_test(0.5, 0.5, 0.5, 0.5, 0.5, 0.5);
    // color_map.random_populate();
    float* data = color_map.get_float_array();
    float* data_copy = color_map.get_float_array_copy();
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F, SCR_WIDTH, SCR_HEIGHT, 0, GL_RGB, GL_FLOAT, data);

    // send texture to shader
    glBindImageTexture(0, textures[0], 0, GL_FALSE, 0, GL_READ_WRITE, GL_RGBA32F); 


    GLuint ssbo_pair[2];
    switch(programShader){
        case(COMPUTE_SSBO_VERTEX):
            // shader.setUV2("ssboDim", SCR_WIDTH, SCR_HEIGHT);

             glGenBuffers(2, ssbo_pair);
            // bind ssbo's
            
            glBindBuffer(GL_SHADER_STORAGE_BUFFER, ssbo_pair[0]);
            glBufferData(GL_SHADER_STORAGE_BUFFER, color_map.get_physical_size(), data, GL_DYNAMIC_COPY);
            glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 0, ssbo_pair[0]);

            glBindBuffer(GL_SHADER_STORAGE_BUFFER, ssbo_pair[1]);
            glBufferData(GL_SHADER_STORAGE_BUFFER, color_map.get_physical_size(), data_copy, GL_DYNAMIC_COPY);
            glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 1, ssbo_pair[1]);
            glBindTexture(GL_TEXTURE_2D, textures[0]);
            break;

        case(COMPUTE_SSBO):
            
            glGenBuffers(2, ssbo_pair);
            // bind ssbo's
            
            glBindBuffer(GL_SHADER_STORAGE_BUFFER, ssbo_pair[0]);
            glBufferData(GL_SHADER_STORAGE_BUFFER, color_map.get_physical_size(), data, GL_DYNAMIC_COPY);
            glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 0, ssbo_pair[0]);

            glBindBuffer(GL_SHADER_STORAGE_BUFFER, ssbo_pair[1]);
            glBufferData(GL_SHADER_STORAGE_BUFFER, color_map.get_physical_size(), data_copy, GL_DYNAMIC_COPY);
            glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 1, ssbo_pair[1]);
            glBindTexture(GL_TEXTURE_2D, textures[0]);
            break;

        case(COMPUTE_TEXTURE):

            glActiveTexture(GL_TEXTURE0 + 1);
            glBindTexture(GL_TEXTURE_2D, textures[1]); // all upcoming GL_TEXTURE_2D operations now have effect on this texture object
            // set the texture wrapping parameters
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);	// set texture wrapping to GL_REPEAT (default wrapping method)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
            // set texture filtering parameters
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);


            // send texture to shader
            glBindImageTexture(1, textures[1], 0, GL_FALSE, 0, GL_WRITE_ONLY, GL_RGBA32F); 
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA32F, SCR_WIDTH, SCR_HEIGHT, 0, GL_RGB, GL_FLOAT, data_copy);
            
            break;



    }
    // delete ddata arrays
    delete data, data_copy;

    
    
    // render loop
    // -----------
    
    // while (!glfwWindowShouldClose(window))
    // {
    float time_sum = 0;
    float start_time = glfwGetTime();
    int num_samples = 100;

    for(int sample = 0; sample < num_samples; ++sample){
        // input
        // -----
        processInput(window);
        // run compute shader
        
        compute_shader.use();
        float frameTime = glfwGetTime();

        for(int iter = 0; iter < 500; ++iter){
            glDispatchCompute(SCR_WIDTH, SCR_HEIGHT, 1);
            // gather results before next iteration
            glMemoryBarrier(GL_SHADER_IMAGE_ACCESS_BARRIER_BIT);

            

            switch(programShader){
                case(COMPUTE_SSBO):
                    // set up current output ssbo as input for next timestep
                    std::swap(ssbo_pair[0], ssbo_pair[1]);
                    glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 0, ssbo_pair[0]);
                    glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 1, ssbo_pair[1]);
    
                break;
               
                case(COMPUTE_SSBO_VERTEX):
                    // set up current output ssbo as input for next timestep
                    std::swap(ssbo_pair[0], ssbo_pair[1]);
                    glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 0, ssbo_pair[0]);
                    glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 1, ssbo_pair[1]);
    
                break;

                case(COMPUTE_TEXTURE):
                    std::swap(textures[0], textures[1]);
                    compute_shader.setFloat("test", sin(glfwGetTime()));
                    glBindImageTexture(0, textures[0], 0, GL_FALSE, 0, GL_READ_WRITE, GL_RGBA32F); 
                    glBindImageTexture(1, textures[1], 0, GL_FALSE, 0, GL_WRITE_ONLY, GL_RGBA32F); 
                    
                break;

            }

        }
        float sample_time = glfwGetTime() - frameTime;
        time_sum += sample_time;
        // render
        // ------
        glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        

        switch(programShader){
                case(COMPUTE_SSBO):
                    
                    ssbo_to_texture.use();
                    glDispatchCompute(SCR_WIDTH, SCR_HEIGHT, 1);
                    glMemoryBarrier(GL_SHADER_IMAGE_ACCESS_BARRIER_BIT);
    
                break;
                
                case(COMPUTE_TEXTURE):
                    glBindTexture(GL_TEXTURE_2D, textures[1]);
                    
                break;
        }

        
        
        // render relaxation
        shader.use();
        // glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 1, ssbo_pair[1]);


       
        glBindVertexArray(VAO);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

        // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
        // -------------------------------------------------------------------------------
        glfwSwapBuffers(window);
        glfwPollEvents();

    
    }
    std::cout << "Net Time:" << glfwGetTime() - start_time << std::endl;
    std::cout << "Mean time per sample:" << time_sum / num_samples << std::endl;




    // glfw: terminate, clearing all previously allocated GLFW resources.
    // ------------------------------------------------------------------
    glfwTerminate();
    return 0;
}



// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow *window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    // make sure the viewport matches the new window dimensions; note that width and 
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);
}